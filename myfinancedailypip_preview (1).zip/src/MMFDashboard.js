
import { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function MMFDashboard() {
  const [tier, setTier] = useState("lower");
  const [amount, setAmount] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [mpesaNumber, setMpesaNumber] = useState("");
  const [balance, setBalance] = useState(12480);
  const [interestToday, setInterestToday] = useState(249.6);
  const [accountBalance, setAccountBalance] = useState(38000); // Example general account balance

  useEffect(() => {
    setBalance(12480);
    setInterestToday(tier === "lower" ? 12480 * 0.02 : 12480 * 0.01);
    setAccountBalance(38000);
  }, [tier]);

  const handleDeposit = () => {
    alert(`Simulate deposit of ${amount} KES to ${tier} tier.`);
  };

  const handleWithdraw = () => {
    alert(`Request withdrawal of ${withdrawAmount} KES to ${mpesaNumber}`);
  };

  return (
    <div className="p-6 space-y-6 bg-pink-50 min-h-screen">
      <Card className="bg-white shadow-xl rounded-2xl p-6">
        <CardContent>
          <h2 className="text-2xl font-bold mb-2">💼 My MMF Balance</h2>
          <p className="text-xl">KES {balance.toLocaleString()}</p>
          <p className="text-sm text-gray-500 mt-2">📈 Earnings Today: +KES {interestToday.toFixed(2)}</p>
          <p className="text-xs text-gray-400">🔄 Last Update: Apr 24, 2025</p>
        </CardContent>
      </Card>

      <Card className="bg-white shadow-xl rounded-2xl p-6">
        <CardContent>
          <h2 className="text-xl font-semibold mb-2">👤 My Account Balance</h2>
          <p className="text-lg text-pink-600">KES {accountBalance.toLocaleString()}</p>
        </CardContent>
      </Card>

      <Card className="bg-white shadow-xl rounded-2xl p-6">
        <CardContent className="space-y-4">
          <h2 className="text-xl font-semibold">📥 Add Funds to MMF</h2>
          <Tabs defaultValue="lower" onValueChange={setTier}>
            <TabsList>
              <TabsTrigger value="lower">Lower (2%)</TabsTrigger>
              <TabsTrigger value="upper">Upper (1%)</TabsTrigger>
            </TabsList>
          </Tabs>
          <Input
            type="number"
            placeholder="Enter amount (KES)"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
          <Button className="bg-pink-500 hover:bg-pink-600 text-white" onClick={handleDeposit}>
            Simulate Deposit
          </Button>
          <p className="text-xs text-gray-400">💡 Use phone number as payment reference</p>
        </CardContent>
      </Card>

      <Card className="bg-white shadow-xl rounded-2xl p-6">
        <CardContent className="space-y-4">
          <h2 className="text-xl font-semibold">📤 Request Withdrawal</h2>
          <p>Available: KES {balance.toLocaleString()}</p>
          <Input
            type="number"
            placeholder="Amount to withdraw"
            value={withdrawAmount}
            onChange={(e) => setWithdrawAmount(e.target.value)}
          />
          <Input
            type="tel"
            placeholder="M-Pesa Number (07XXXXXXXX)"
            value={mpesaNumber}
            onChange={(e) => setMpesaNumber(e.target.value)}
          />
          <Button className="bg-pink-500 hover:bg-pink-600 text-white" onClick={handleWithdraw}>
            Withdraw Now
          </Button>
          <p className="text-xs text-gray-400">⚠️ Processed within 24 hours</p>
        </CardContent>
      </Card>
    </div>
  );
}
